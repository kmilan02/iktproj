﻿using Microsoft.VisualStudio.TestTools.UnitTesting;
using HegyekMo;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace HegyekMo.Tests
{
    [TestClass()]
    public class OrszagTests
    {
        [TestMethod()]
        public void AddHegyTest()
        {
            Assert.Fail();
        }

        public void OrszagTest()
        {
            Assert.Fail();
        }

        [TestMethod()]
        public void haromezerlabTest()
        {
            Assert.Fail();
        }
    }
}