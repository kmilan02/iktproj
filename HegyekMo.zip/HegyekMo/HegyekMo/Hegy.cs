﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace HegyekMo
{
    public class Hegy
    {
        string nev;
        string hegyseg;
        int magassag;
        public string Nev
        {
            get => nev;
            set => nev = value;
        }
        public string Hegyseg
        {
            get => hegyseg;
            set => hegyseg = value;
        }
        public int Magassag
        {
            get => magassag;
            set => magassag = value;
        }
        public Hegy(string nev, string hegyseg, int magassag)
        {
            this.nev = nev;
            this.hegyseg = hegyseg;
            this.magassag = magassag;
        }
        public override string ToString()
        {
            return $"\n\tNév: {this.Nev}\n\tHegység: {this.Hegyseg}\n\tMagasság: {this.Magassag}";
        }
    }
}
