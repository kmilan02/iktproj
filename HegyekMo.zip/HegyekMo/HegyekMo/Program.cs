﻿using HegyekMo;

static double AvgHegy(List<Hegy> hegyekList)
{
    int sum = 0;
    for (int i = 0; i < hegyekList.Count; i++)
    {
        sum += hegyekList[i].Magassag;
    }
    return sum / (double)hegyekList.Count;
}

static int HighestHegy(List<Hegy> hegyekList)
{
    int[] items = hegyekList.Select(a => a.Magassag).ToArray();
    return Array.IndexOf(items, items.Max());
    //return Array.IndexOf(hegyekList.Select(a => a.Magassag).ToArray(), hegyekList.Select(a => a.Magassag).ToArray().Max());
}

static bool MagasabbHegycsucs(List<Hegy> hegyekList, int bekertmagassag)
{
    bool talalat = false;
    int index = 0;
    while(!talalat && index < hegyekList.Count)
    {
        if (hegyekList[index].Magassag > bekertmagassag && hegyekList[index].Hegyseg == "Börzsöny") talalat = true;
        index++;
    }

    return talalat;
}

static int haromezerlab(List<Hegy> hegyekList)
{
    int magasabb = 0;
    for (int i = 0; i < hegyekList.Count; i++)
    {
        if (hegyekList[i].Magassag * 3.280839895 > 3000) magasabb++;
    }
    return magasabb;
}

static void Statisztika(List<Hegy> hegyekList)
{
    Dictionary<string, int> dict = new Dictionary<string, int>();

    foreach (Hegy hegy in hegyekList)
    {
        if (dict.ContainsKey(hegy.Hegyseg))
        {
            dict[hegy.Hegyseg]++;
        }
        else
        {
            dict.Add(hegy.Hegyseg, 1);
        }
    }

    foreach (var item in dict)
    {
        Console.WriteLine($"\t{item.Key} - {item.Value} db");
    }
}

static void FajlbabaIras(List<Hegy> hegyekList)
{
    StreamWriter writer = new StreamWriter("bukk-videk.txt");
    writer.WriteLine("Hegycsúcs neve;Magasság láb");
    foreach (var item in hegyekList)
    {
        if (item.Hegyseg == "Bükk-vidék")
        {
            writer.WriteLine($"{item.Hegyseg};{(item.Magassag * 3.280839895).ToString("G5")}");
        }
    }
    writer.Close();
}

StreamReader reader = new StreamReader("hegyekMo.txt");
reader.ReadLine();

Orszag Magyarorszag = new Orszag("Magyarország");
List<Hegy> hegyekList = new List<Hegy>();

while(!reader.EndOfStream)
{
    string[] line = reader.ReadLine()!.Split(";");
    Hegy hegy = new Hegy(line[0], line[1], Convert.ToInt32(line[2]));

    hegyekList.Add(hegy);
    Magyarorszag.AddHegy(hegy);
}
reader.Close();

Console.WriteLine($"3. feladat: Hegycsúcsok száma: {hegyekList.Count} db");
Console.WriteLine($"4. feladat: Hegycsúcsok átlagos magassága: {AvgHegy(hegyekList)} m");
Console.WriteLine($"5. feladat: A legmagasabb hegycsúcs adatai: {hegyekList[HighestHegy(hegyekList)]}");
Console.Write("6. feladat: Kérek egy magasságot: ");
int bekertmagassag = Convert.ToInt32(Console.ReadLine());
Console.WriteLine(MagasabbHegycsucs(hegyekList, bekertmagassag) ? $"\tVan {bekertmagassag} m-nél magasabb hegycsúcs a Börzsönyben." : $"\tNincs {bekertmagassag} m-nél magasabb hegycsúcs a Börzsönyben.");
Console.WriteLine($"7. feladat: 3000 lábnál magasabb hegycsúcsok száma: {haromezerlab(hegyekList)}");
Console.WriteLine($"8. feladat: Statisztika");
Statisztika(hegyekList);
Console.WriteLine("9. feladat: bukk-videk.txt");
FajlbabaIras(hegyekList);