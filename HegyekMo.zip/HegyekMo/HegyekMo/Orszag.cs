﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace HegyekMo
{
    public class Orszag
    {
        string nev;
        List<Hegy> orszagHegyei = new List<Hegy>();

        public string Nev
        {
            get => nev;
            set => nev = value;
        }
        public List<Hegy> OrszagHegyei
        {
            get => orszagHegyei;
        }
        public void AddHegy(Hegy hegy)
        {
            this.orszagHegyei.Add(hegy);
        }
        public Orszag(string nev)
        {
            this.nev = nev;
        }
        public int haromezerlab()
        {
            int magasabb = 0;
            foreach (Hegy item in this.orszagHegyei)
            {
                if (item.Magassag * 3.280839895 > 3000) magasabb++;
            }
            return magasabb;
        }
    }
}
