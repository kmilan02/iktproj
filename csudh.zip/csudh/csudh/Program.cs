﻿using csudh;

static string DomainAtLevel(List<Domain> domainList, int domain, int level)
{
    string[] splittedDomain = domainList[domain].DomainName.Split(".");
    Array.Reverse(splittedDomain);
    try
    {
        return splittedDomain[level];
    }
    catch (Exception e)
    {

        return "nincs";
    }
}

StreamReader reader = new StreamReader("csudh.txt");
reader.ReadLine();

List<Domain> domainList = new List<Domain>();

while(!reader.EndOfStream)
{
    string[] line = reader.ReadLine().Split(';');
    Domain domain = new Domain();

    domain.DomainName = line[0];
    domain.IpAddress = line[1];

    domainList.Add(domain);
}
reader.Close();

Console.WriteLine($"3. feladat: Domainek száma: {domainList.Count}");
Console.WriteLine($"5. feladat: Az első domain felépítése:");
for (int i = 0; i < 5; i++)
{
    Console.WriteLine($"\t{i + 1}. szint: {DomainAtLevel(domainList, 0, i)}");
}

StreamWriter writer = new StreamWriter(@"C:\\Users\\Hunter\\Downloads\\table.html");

writer.WriteLine("<table>\n<tr>\n<th style='text-align: left'>Ssz</th>\n<th style='text-align: left'>Host Domain neve</th>\n<th style='text-align: left'>Host IP címe</th>");
for (int i = 0; i < 5; i++)
{
    writer.WriteLine($"<th style='text-align: left'>{i}. szint</th>");
}
writer.WriteLine("</tr>");
for (int i = 0; i < 5; i++)
{
    writer.WriteLine($"<tr>\n<th style='text-align: left'>{i + 1}.</th>\n<td>{domainList[i].DomainName}<td>\n<td>{domainList[i].IpAddress}</td>");
    for (int j = 0; j < 5; j++)
    {
        writer.WriteLine($"<td>{DomainAtLevel(domainList, i, j)}</td>");
    }
    writer.WriteLine("</tr>");
}
writer.Close();