﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace csudh
{
    internal class Domain
    {
        string domainname;
        string ipaddress;

        public string DomainName
        {
            get { return domainname; }
            set { domainname = value; }
        }

        public string IpAddress
        {
            get { return ipaddress; }
            set { ipaddress = value; }
        }
    }
}
